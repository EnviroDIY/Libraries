# Example A: Using the wildcard - Getting single sensor information

This is a simple demonstration of the SDI-12 library for Arduino.
It requests information about a single attached sensor, including its address and manufacturer info, and prints it to the serial port
