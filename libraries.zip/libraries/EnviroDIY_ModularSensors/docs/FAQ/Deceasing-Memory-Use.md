# Decreasing Memory Footprint <!-- {#page_memory_use} -->

There are things you could do to decrease memory use.

Decrease max num vars etc

@todo The decreasing memory footprint section is not yet written.
