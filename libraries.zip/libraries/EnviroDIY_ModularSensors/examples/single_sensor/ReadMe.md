# Example using the Modular Sensors Library to Communicate with a Single Sensor

This somewhat trivial example show making use of the unified set of commands to print data from a MaxBotix ultrasonic range finder to the serial port.  It is somewhat complicated by showing the defining and selection of a HardwareSerial port for a SAMD21 board and the selection of a SoftwareSerial port for a AVR board.
