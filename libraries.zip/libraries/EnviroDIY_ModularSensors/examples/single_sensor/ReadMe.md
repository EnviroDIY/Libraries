[//]: # ( @page single_sensor_example Single %Sensor Example )
# Using ModularSensors to Communicate with a Single Sensor

This somewhat trivial example show making use of the unified set of commands to print data from a MaxBotix ultrasonic range finder to the serial port.
It also shows creating a calculated variable which is the water depth.

_______

[//]: # ( @section single_sensor_full The Complete Example Code: )
