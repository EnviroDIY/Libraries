[//]: # ( @page menu_example A la carte Example )
# Example showing all possible functionality

This shows most of the functionality of the library at once.
It has code in it for every possible sensor and modem and for both AVR and SAMD boards.
This example should *never* be used directly, but rather taken as a template and all parts that do not apply cut out.

Any line containing the word *MS_BUILD_TESTING* is to help ensure the library builds correctly in all environments.
Those lines should be removed when using the example on your own board.
