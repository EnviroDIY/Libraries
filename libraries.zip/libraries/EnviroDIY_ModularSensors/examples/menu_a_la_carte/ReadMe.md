
### [menu_a_la_carte](https://github.com/EnviroDIY/ModularSensors/tree/master/examples/menu_a_la_carte)

This shows most of the functionality of the library at once.  It has code in it for every possible sensor and modem and for both AVR and SAMD boards.  This example should *never* be used directly, but rather taken as a template and all parts that do not apply cut out.

Any line containing the word *MS_BUILD_TESTING* is to help ensure the library builds correctly in all environments.  Those lines should be removed when using the example on your own board.
