# Example using the Modular Sensors Library to Calculate Results based on Measured Values and Send Both Measured and Calculated Values to the EnviroDIY Data Portal

This example demonstrates how to work with calculated variables.
