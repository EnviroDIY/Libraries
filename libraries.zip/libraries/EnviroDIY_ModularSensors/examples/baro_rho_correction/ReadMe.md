# Example using the Modular Sensors Library to Calculate Results based on Measured Values and Send Both Measured and Calculated Values to the EnviroDIY Data Portal

Like the double_logger example, this showcases how to set up your own logging loop rather than using the log() function.  In this case, though, there is only a single logger, but we are adding some extra calculated variables to the final output.
