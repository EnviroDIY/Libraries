# Example using the Modular Sensors Library to Print Data to a Serial Port

This shows the simplest use of a "variable array" object to update the values of all of the variables by calling the parent sensor update functions and then printing all of the results to a serial port.  The processor then goes to sleep between readings.  This example calls on at least one of every single sensor available in this library.  Please do not try to run the example exactly as written, but delete the chunks of code pertaining to sensors that you do not have attached.
