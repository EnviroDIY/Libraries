# Sensor Tests

These are not tests of the library itself, but short scripts to test the sensor connections with the Mayfly.  These were mostly used developing and improving the "update" functions in the library.  Some of these sketches may no longer be functional.
