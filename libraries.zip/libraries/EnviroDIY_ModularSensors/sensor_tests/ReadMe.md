# Sensor Tests

These are not tests of the library itself, but short scripts to test the sensor connections with the Mayfly.  These are mostly helpful in developing and improving the "update" functions in the library.
