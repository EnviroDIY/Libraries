# SoftwaterSerialMod
A modified version of the Arduino built-in SoftwareSerial library to work with other libraries using pin change interrupts.  This version only uses PCINT1 and PCINT2.
