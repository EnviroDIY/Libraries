# SoftwaterSerialMod
A modified version of the Arduino built-in SoftwareSerial library to work with the EnviroDIY Mayfly

This makes the correct ports available to work simultaneously with the SDI-12Mod and PcIntMod libraries.
