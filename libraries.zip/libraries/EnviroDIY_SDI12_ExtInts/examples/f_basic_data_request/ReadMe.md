[//]: # ( @page example_f_page Example F: Basic Data Request to a Single Sensor )
# Example F: Basic Data Request to a Single Sensor

This is a simple demonstration of the SDI-12 library for Arduino.

This is a very basic (stripped down) example where the user initiates a measurement and receives the results to a terminal window without typing numerous commands into the terminal.

[//]: # ( @include{lineno} f_basic_data_request.ino )
