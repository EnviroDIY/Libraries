### YosemiTech Calibration Protocols & Spreadsheets

#### WORK IN PROGRESS

#### Cleaning pH electrode

For environmental deployments, we suggest would suggest this order:
- Wipe, brush, and rinse with DI water to physically remove all biofilms.
- Rinse with Methanol
- Soak overnight in lab detergent, preferably with an enzyme to also remove proteins. Rinse with DI water.
- Soak in 1% HCl for 10 min. Rinse with DI water.
- Calibrate sensor.
Any of these steps can be skipped, based on the type of fouling and how easily the sensor recalibrates.

For for more detailed information on each of these steps, see https://www.coleparmer.com/tech-article/how-to-store-clean-and-recondition-ph-electrodes 

