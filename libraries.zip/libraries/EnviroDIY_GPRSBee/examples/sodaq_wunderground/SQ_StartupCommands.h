#ifndef STARTUPCOMMANDS_H_
#define STARTUPCOMMANDS_H_

#include <Arduino.h>

void startupCommands(Stream & stream);


#endif /* STARTUPCOMMANDS_H_ */
